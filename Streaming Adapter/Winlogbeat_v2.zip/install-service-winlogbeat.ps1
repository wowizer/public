# Delete and stop the service if it already exists.
if (Get-Service "Wowizer Winlogbeat" -ErrorAction SilentlyContinue) {
  Stop-Service "Wowizer Winlogbeat"
  (Get-Service "Wowizer Winlogbeat").WaitForStatus('Stopped')
  Start-Sleep -s 1
  sc.exe delete "Wowizer Winlogbeat"
}

$workdir = Split-Path $MyInvocation.MyCommand.Path

# Create the new service.
New-Service -name "Wowizer Winlogbeat" `
  -displayName "Wowizer Winlogbeat" `
  -binaryPathName "`"$workdir\winlogbeat.exe`" --environment=windows_service -c `"$workdir\winlogbeat.yml`" --path.home `"$workdir`" --path.data `"$env:PROGRAMDATA\winlogbeat`" --path.logs `"$env:PROGRAMDATA\winlogbeat\logs`" -E logging.files.redirect_stderr=true"

# Attempt to set the service to delayed start using sc config.
Try {
  Start-Process -FilePath sc.exe -ArgumentList 'config "Wowizer Winlogbeat" start= delayed-auto'
}
Catch { Write-Host -f red "An error occurred setting the service to delayed start." }
