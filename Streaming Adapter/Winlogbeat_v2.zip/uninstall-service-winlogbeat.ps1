# Delete and stop the service if it already exists.
if (Get-Service "Wowizer TPM Winlogbeat" -ErrorAction SilentlyContinue) {
  Stop-Service "Wowizer TPM Winlogbeat"
  (Get-Service "Wowizer TPM Winlogbeat").WaitForStatus('Stopped')
  Start-Sleep -s 1
  sc.exe delete "Wowizer TPM Winlogbeat"
}
