# Delete and stop the service if it already exists.
if (Get-Service "Wowizer Winlogbeat" -ErrorAction SilentlyContinue) {
  Stop-Service "Wowizer Winlogbeat"
  (Get-Service "Wowizer Winlogbeat").WaitForStatus('Stopped')
  Start-Sleep -s 1
  sc.exe delete "Wowizer Winlogbeat"
}
