# Set environment variables for Wowizer
param (
    [string]$tenantID,
    [string]$QlickIp
)

if (-not $tenantID -or -not $QlickIp) {
    Write-Host "Please provide both the Unique Stream ID (tenantID) and Qlick IP."
    exit 1
}

$elevated = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
if ($elevated -ne 'True'){
    Write-Output "You are not Administrator User. You need to Run PowerShell Script in as 'Windows PowerShell with Administrator' to setup wowizer realtime"
    break;
    }else{

[Environment]::SetEnvironmentVariable("QLIK_LOGS_ROOT_PATH", "C:\ProgramData\Qlik\Sense\Log", [System.EnvironmentVariableTarget]::Machine)
[Environment]::SetEnvironmentVariable("WOW_Ingestion_ID", "$tenantID", [System.EnvironmentVariableTarget]::Machine)

$HealthDataDownloadURL = "https://github.com/wowizer/public/raw/wowizer-documents/HealthData/v2/HealthData_Wowizer_v2.zip"
$winlogbeatDownloadURL = "https://github.com/wowizer/public/raw/wowizer-documents/Streaming%20Adapter/Winlogbeat.zip"
$filebeatDownloadURL = "https://github.com/wowizer/public/raw/wowizer-documents/Streaming%20Adapter/filebeat_wowizer_v1.zip"

# Create the wowizer directory
Write-Output "Creating wowizer directory in C drive"
New-Item -ItemType Directory -Path "C:\wowizer"

# Download and unzip HealthData inside wowizer directory
Write-Output "Downloading HealthData_Wowizer_v2.zip file"
Invoke-WebRequest -Uri $HealthDataDownloadURL -OutFile "C:\wowizer\HealthData_Wowizer_v2.zip"
Expand-Archive -Path "C:\wowizer\HealthData_Wowizer_v2.zip" -DestinationPath "C:\wowizer\HealthData_Wowizer_v2"
Remove-Item -Path "C:\wowizer\HealthData_Wowizer_v2.zip" -Force
Write-Output "Download completed"

# Download and unzip Winlogbeat inside wowizer directory
Write-Output "Downloading Winlogbeat.zip file"
Invoke-WebRequest -Uri $winlogbeatDownloadURL -OutFile "C:\wowizer\Winlogbeat.zip"
Expand-Archive -Path "C:\wowizer\Winlogbeat.zip" -DestinationPath "C:\wowizer\Winlogbeat"
Remove-Item -Path "C:\wowizer\Winlogbeat.zip" -Force
Write-Output "Download completed"

# Download and unzip Filebeat inside wowizer directory
Write-Output "Downloading filebeat_wowizer_v1.zip file"
Invoke-WebRequest -Uri $filebeatDownloadURL -OutFile "C:\wowizer\filebeat_wowizer_v1.zip"
Expand-Archive -Path "C:\wowizer\filebeat_wowizer_v1.zip" -DestinationPath "C:\wowizer\filebeat_wowizer_v1"
Remove-Item -Path "C:\wowizer\filebeat_wowizer_v1.zip" -Force
Write-Output "Download completed"

# Update Qlik Sense Server IP
$filePath = "C:\wowizer\HealthData_Wowizer_v2\wowizer_healthcheck.bat"
(Get-Content $filePath) | ForEach-Object { $_ -replace "<Qlik host ip>", "$QlickIp" } | Set-Content $filePath

#Start HealthData Service
Write-Output "Starting healthcheck installation....."
cd "C:\wowizer\HealthData_Wowizer_v2"
.\healthcheckstart.bat -ArgumentList "/silent /other-parameters"
Start-Sleep -Seconds 15
Write-Output "Healthcheck installation completed"
# Check healthcheckdata.txt
$directoryPath = "C:\wowizer\HealthData_Wowizer_v2\"
$filePath = Join-Path -Path $directoryPath -ChildPath "healthcheckdata.txt"

if (Test-Path -Path $filePath -PathType Leaf) {
    Write-Host "The file $filePath exists in the directory."
    Write-Output "Starting winlogbeat installation....."
    # Install Winlogbeat and Filebeat
    cd "C:\wowizer\Winlogbeat"
    PowerShell.exe -ExecutionPolicy UnRestricted -File .\install-service-winlogbeat.ps1
	Start-Service winlogbeat
	Start-Sleep -Seconds 20
    Write-Output "Starting filebeat installation....."
    cd "C:\wowizer\filebeat_wowizer_v1"
    PowerShell.exe -ExecutionPolicy UnRestricted -File .\install-service-filebeat.ps1
    Start-Service filebeat
	Start-Sleep -Seconds 20
    Get-Service Filebeat
    Get-Service winlogbeat
	Start-Sleep -Seconds 10
    Write-Host "Installation and service start completed."
    exit 0
} else {
    Write-Host "The file $filePath does not exist in the directory."
    exit 0
}
}
