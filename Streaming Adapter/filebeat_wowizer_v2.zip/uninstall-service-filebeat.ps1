# Delete and stop the service if it already exists.
if (Get-Service -Name "Wowizer TPM Filebeat" -ErrorAction SilentlyContinue) {
  $service = Get-WmiObject -Class Win32_Service -Filter "name='Wowizer TPM Filebeat'"
  $service.StopService()
  Start-Sleep -s 1
  $service.delete()
}
