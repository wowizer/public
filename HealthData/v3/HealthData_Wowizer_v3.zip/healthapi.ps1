# Define the URL, username, and password
param (
    [string]$url,
    [string]$username,
    [string]$passwd
)



# Initialize variables
$response = $null
$filteredResponseJson = ""
# Initialize an error object
$errorObject = @{
    ErrorMessage = ""
}

# Try to send the HTTP request and handle errors using curl
try {
    # Create a credential object for authentication

    # Build the curl command
    $curlCommand = ".\curl.exe -k -L --ntlm -H 'User-Agent: Windows' -H 'Cache-Control: no-cache' --user $($username):$($passwd) $($url)"


    # Execute the curl command and capture the output
    $curlOutput = Invoke-Expression $curlCommand

    # Check if the curl output is not empty or null
    if ($curlOutput -ne $null -and $curlOutput -ne "") {
        # Convert the curl output to JSON
        $response = ConvertFrom-Json $curlOutput

        # Remove specific keys from the JSON response
        $keysToRemove = @("apps")
        $filteredResponse = $response | ForEach-Object {
            $entry = $_
            foreach ($keyToRemove in $keysToRemove) {
                if ($entry.PSObject.Properties[$keyToRemove]) {
                    $entry.PSObject.Properties.Remove($keyToRemove)
                }
            }
            $entry
        }

        # Convert the filtered response back to JSON
        $filteredResponseJson = $filteredResponse | ConvertTo-Json
    }
}
catch {
    # Handle errors here
    $errorMessage = $_.Exception.Message
    $errorObject.ErrorMessage = $errorMessage

    # Convert the error object to JSON
    $errorJson = $errorObject | ConvertTo-Json

    # Output the JSON-formatted error message
    Write-Output $errorJson
}

# Output the filtered JSON response or a blank JSON object in case of an error
if ($filteredResponseJson -ne "") {
    Write-Output $filteredResponseJson
}
else {
    # Return a blank JSON object
    Write-Output "{}"
}
