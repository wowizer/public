# Set the execution policy (if not already set)
Set-ExecutionPolicy RemoteSigned -Scope Process -Force

# Initialize an object to store disk information
$diskInfoObject = @{}

# Get disk information for each logical disk
$logicalDisks = Get-WmiObject -Class Win32_LogicalDisk

$i = 1
foreach ($disk in $logicalDisks) {
    $name = $disk.DeviceID.TrimEnd(":")
    $totalDisk = [math]::Round($disk.Size / 1GB, 2)
    $freeSpace = [math]::Round($disk.FreeSpace / 1GB, 2)
    $diskUse = [math]::Round(($totalDisk - $freeSpace), 2)
	
	if ($totalDisk -gt 0) {
        $diskUsePercentage = [math]::Round(($diskUse / $totalDisk) * 100, 2)
    } else {
        $diskUsePercentage = 0
    }

    # Create a custom object for each disk
    $diskInfo = @{
        "Name" = $name
        "TotalDisk" = $totalDisk
        "FreeSpace" = $freeSpace
        "DiskUse" = $diskUse
		"DiskUsagePercentage" = $diskUsePercentage
    }
    
    # Add the custom object to the main object with a custom key (e.g., "d1," "d2")
    $diskInfoObject["d$i"] = $diskInfo
    $i++
}

# Convert the main object to JSON
$diskInfoObject | ConvertTo-Json
