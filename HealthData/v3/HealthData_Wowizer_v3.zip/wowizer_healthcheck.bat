@echo off
setlocal

set "serviceNameToCheck=QlikSenseEngineService"
set "serviceToStop=Wowizer TPM HealthCheck"

sc query "%serviceNameToCheck%" | find "STATE" | find "RUNNING" > nul
if %errorlevel% equ 0 (
    echo Service "%serviceNameToCheck%" is running. Running the first script...
    call :RunFirstScript
) else (
    echo Service "%serviceNameToCheck%" is not running. Attempting to stop service "%serviceToStop%"...
    sc stop "%serviceToStop%"
    if %errorlevel% equ 0 (
        echo Service "%serviceToStop%" has been stopped.
    ) else (
        echo Failed to stop service "%serviceToStop%" or it may not exist.
    )
)

:end
endlocal
exit /b 0

:RunFirstScript
echo Running the first script...
@echo off
setlocal enabledelayedexpansion

set url=https://<YOUR QLIK HOST IP>/healthapi/engine/healthcheck/
set username=sa_repository
set password=xxxxxxxxxxx
set interval=60
set loopcount=2
set fname=".\healthcheckdata.txt"

echo %url%
echo %username%
echo %password%
echo %interval%
rem echo %loopcount%
echo "---------------------------------------------------------"

for /F "eol=; tokens=2 delims=^(^)" %%I in ('wmic timezone get caption /format:list') do (
   set "daUtcTimeZone=%%I"
)

set "daUtcBiasHHMM=%daUtcTimeZone:UTC=%"

echo daUtcTimeZone: %daUtcTimeZone%
echo daUtcBiasHHMM: %daUtcBiasHHMM%

echo "Running below command continuously and writing output to %fname% for %loopcount% iterations"

rem SET cmd=curl -k -L --ntlm -H "User-Agent: Windows" -H "Cache-Control: no-cache" -u %username%:%password% %url%
rem echo %cmd%

TIMEOUT 5 /nobreak

echo "-------------------STARTING--------------------------------------"

:loop

rem for /f "tokens=*" %%a in ('%cmd%') do set cmop=%%a

for /f "delims=" %%a in ('wmic OS Get localdatetime ^| find "."') do set DateTime=%%a
set year=%DateTime:~0,4%
set month=%DateTime:~4,2%
set day=%DateTime:~6,2%
set hour=%DateTime:~8,2%
set min=%DateTime:~10,2%
set sec=%DateTime:~12,2%

set complete_datetime=%year%%month%%day%T%hour%%min%%sec%%daUtcBiasHHMM%
ECHO complete_datetime:%complete_datetime%

for /f "delims=" %%H in ('hostname') do set hostname=%%H

SET Timestamp=%date:~6,8%%date:~3,2%%date:~0,2%T%time:~0,2%%time:~3,2%%time:~6,2%%daUtcBiasHHMM%
ECHO New Format 2: %Timestamp%

for /f %%D in ('powershell -command "(Get-WmiObject -Class Win32_LogicalDisk | Measure-Object -Property Size -Sum).Sum / 1GB"') do set "TotalDiskSpace=%%D"
for /f %%D in ('powershell -command "(Get-WmiObject -Class Win32_LogicalDisk | Measure-Object -Property Freespace -Sum).Sum / 1GB"') do set "FreeSpace=%%D"
for /f %%D in ('powershell -command "(Get-CimInstance Win32_PhysicalMemory | Measure-Object -Property Capacity -Sum).Sum / 1GB"') do set "TotalRAM=%%D"
for /f %%D in ('powershell -command "(Get-Counter \"\Memory\Available MBytes\").CounterSamples.CookedValue / 1024"') do set "FreeRAM=%%~D"

:: Calculate the difference
::set /a "DiskSpaceInUse=TotalDiskSpace - FreeSpace"
for /f %%D in ('powershell -command "[math]::Round(%TotalRAM% - %FreeRAM%, 2)"') do set "UsedRAM=%%D"
for /f %%D in ('powershell -command "[math]::Round(%TotalDiskSpace% - %FreeSpace%, 2)"') do set "DiskSpaceInUse=%%D"


:: Calculate percentages
::set /a "DiskUsagePercentage = (DiskSpaceInUse * 100) / TotalDiskSpace"
for /f %%D in ('powershell -command "[math]::Round((%DiskSpaceInUse% * 100) / %TotalDiskSpace%, 2)"') do set "DiskUsagePercentage=%%D"
for /f %%A in ('powershell -command "$usedMemory = Get-WmiObject -Class Win32_OperatingSystem; $totalMemory = $usedMemory.TotalVisibleMemorySize; $freeMemory = $usedMemory.FreePhysicalMemory; $usedMemoryPercentage = ($totalMemory - $freeMemory) / $totalMemory * 100; Write-Output $usedMemoryPercentage"') do set "UsedMemoryPercentage=%%A"
for /f %%D in ('powershell -command "[math]::Round(%UsedMemoryPercentage%, 2)"') do set "UsedMemoryPercentage=%%D"

rem Define the PowerShell command
set "ps_command=PowerShell.exe -ExecutionPolicy Bypass -File diskinfo.ps1"

rem Initialize the variable to store the PowerShell output
set "ps_output="

rem Run the PowerShell command and capture its output into a variable
for /f "delims=" %%a in ('%ps_command%') do (
    set "ps_output=!ps_output!%%a"
)

rem Define the PowerShell command
set "ps_command1=PowerShell.exe -ExecutionPolicy Bypass -File healthapi.ps1 -url %url% -username %username% -passwd %password%"

rem Initialize the variable to store the PowerShell output
set "ps_health_output="

rem Run the PowerShell command and capture its output into a variable
for /f "delims=" %%a in ('%ps_command1%') do (
    set "ps_health_output=!ps_health_output!%%a"
)


rem Construct the JSON output
set json_output={"Timestamp":"%complete_datetime%", "Hostname": "%hostname%", "healthdata": %ps_health_output%, "TotalDiskSpace": %TotalDiskSpace%, "FreeSpace": %FreeSpace%, "DiskSpaceInUse": %DiskSpaceInUse%, "DiskUsagePercentage": %DiskUsagePercentage%, "TotalRAM": %TotalRAM%, "ServerFreeRAM": %FreeRAM%,  "ServerRAMUsed": %UsedRAM%,  "ServerRAMUsagePercentage": %UsedMemoryPercentage%, "disk_info": %ps_output%}

rem Calculate RAM usage percentage
for /f "tokens=15 delims=:, " %%a in ('echo %json_output% ^| find "committed"') do set "committed=%%a"
for /f %%D in ('powershell -command "[math]::Round(%committed% / 1024, 2)"') do set "committed_gb=%%D"
for /f %%D in ('powershell -command "[math]::Round((%committed_gb% * 100) / %TotalRAM%, 2)"') do set "ram_usage_percentage=%%D"

if defined committed (
    set update_json_output={"Timestamp":"%complete_datetime%", "Hostname":"%hostname%", "healthdata":%ps_health_output%, "TotalDiskSpace":%TotalDiskSpace%, "FreeSpace":%FreeSpace%, "DiskSpaceInUse":%DiskSpaceInUse%, "DiskUsagePercentage":%DiskUsagePercentage%, "TotalRAM":%TotalRAM%, "ServerFreeRAM":%FreeRAM%, "ServerRAMUsed":%UsedRAM%, "ServerRAMUsagePercentage":%UsedMemoryPercentage%, "EngineRAMUsagePercentage":%ram_usage_percentage%, "EngineRAMCommited":%committed_gb%, "disk_info":%ps_output%}	
) else (
	set update_json_output={"Timestamp":"%complete_datetime%", "Hostname":"%hostname%", "TotalDiskSpace":%TotalDiskSpace%, "FreeSpace":%FreeSpace%, "DiskSpaceInUse":%DiskSpaceInUse%, "DiskUsagePercentage":%DiskUsagePercentage%, "TotalRAM":%TotalRAM%, "ServerFreeRAM":%FreeRAM%, "ServerRAMUsed":%UsedRAM%, "ServerRAMUsagePercentage":%UsedMemoryPercentage%, "disk_info":%ps_output%}
)

:: Append JSON output to the file
echo %update_json_output%>>%fname%

TIMEOUT %interval% /nobreak

goto loop

:exitloop
echo "Ran for max iterations/run. Now stopped. Please restart if required"

pause

exit /b 0
