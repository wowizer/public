nssm stop "Wowizer TPM HealthCheck"


nssm remove "Wowizer TPM HealthCheck" confirm
