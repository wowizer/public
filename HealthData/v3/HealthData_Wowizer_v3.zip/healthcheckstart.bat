@echo off

nssm install "Wowizer TPM HealthCheck" "%CD%\wowizer_healthcheck.bat"

nssm set "Wowizer TPM HealthCheck" Description "Wowizer TPM HealthCheck"

nssm start "Wowizer TPM HealthCheck"
pause
