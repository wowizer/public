var currentUser;
var client_ip;
var version;
let browser;
var appName;
var QlikHostname;
//const tenant ='chjlzg9vbguzmdm4nte4nda3'; //Enter your Tenant name Here
var host=window.location.href.split(/\//gm)[2];
//var host="192.168.1.151";
var backend_folder="feedback_api";
define( ["angular","qlik", "text!./template.html","text!./config.json","css!./scoped-bootstrap.css","css!./feedback.css","css!./jquery-ui.css"],
	function ( angular, qlik, template,config ) {  //"text!./config.json"=>json file, "./config"=>js file
	let confJSON = JSON.parse(JSON.stringify(config))
	let tenant = JSON.parse(confJSON).tenant
	let hostname =JSON.parse(confJSON).hostname
	//console.log("from json file", tenant ,hostname)
	//console.log("from js file",jsconfig.tenant )
	
	var CurrSheetID = qlik.navigation.getCurrentSheetId();
		var AppID = qlik.currApp(this).selectionState();
		qlik.currApp().getAppLayout().then(applayout => {
			appName = applayout.layout.qTitle;
			
			
			qlik.currApp().createGenericObject( {
				user: {
					qStringExpression: "=SubField(OSUser(),';',1)" //"=OSUser()"
				}
			}, function ( reply ) {
				//console.log("user>>",reply.user);
				QlikHostname = reply.user.split("=")[1]
				console.log("QlikHostname",QlikHostname)
			});
			
			
			//console.log(appName);
		});
		$.getJSON("https://api.ipify.org?format=json",function(data) {

			// to do - please switch to apache request header
			client_ip = data.ip;
		})
		return {
			template: template,
			support: {
				snapshot: false,
				export: false,
				exportData: false
			},
			paint: function () {
				return qlik.Promise.resolve();
							},
			controller: ['$scope', '$http', function ( $scope, $http ) {
				//add your rendering code here
                 //get current app selection and informations
			

				
				qlik.getGlobal().getAuthenticatedUser(function(res) { //get Qlik userid
                        currentUser = res.qReturn;
						var val = currentUser.replace(/\\/g, "");
                        if (currentUser.indexOf("UserId") !== -1) {
                            currentUser = currentUser.split("=")[2];
                        }
				});
				
				const useragent =navigator.saysWho = (() => {  //get browser name and version
					const { userAgent } = navigator
					let match = userAgent.match(/(opera|chrome|safari|firefox|msie|trident(?=\/))\/?\s*(\d+)/i) || []
					let temp

					if (/trident/i.test(match[1])) {
					temp = /\brv[ :]+(\d+)/g.exec(userAgent) || []

					 `IE ${temp[1] || ''}`
					}

					if (match[1] === 'Chrome') {
					temp = userAgent.match(/\b(OPR|Edge)\/(\d+)/)

					if (temp !== null) {
					 temp.slice(1).join(' ').replace('OPR', 'Opera')
					}

					temp = userAgent.match(/\b(Edg)\/(\d+)/)

					if (temp !== null) {
					 temp.slice(1).join(' ').replace('Edg', 'Edge (Chromium)')
					}
					}

					match = match[2] ? [ match[1], match[2] ] : [ navigator.appName, navigator.appVersion, '-?' ]
					temp = userAgent.match(/version\/(\d+)/i)
					
					if (temp !== null) {
					match.splice(1, 1, temp[1])
					}
					//console.log("match",match.join(' v'));
					browser = match.join(' v');
					return match.join(' v')
				})()

				
				$(".feedmodalcls").on('click', function(){
					var ele = document.getElementsByName('options');
					for(i = 0; i < ele.length; i++) {
						if(ele[i].checked){
							ele[i].checked = false;
						}
					}
					$('#txtlen').text("0");
					
					$scope.problem = "";
					$scope.feedbackcomment = "";
					$("#feedbackcomment").val("");
				});
				
				$("#btnfeedback").on('click', function(){
					//console.log($(".qv-object").css("z-index","unset"))
					$(".qv-object").css("z-index","unset")
					$("#feedbackform").show();
					$("#btnfeed").show();
				});
				
				$('textarea').keyup(function(e) { //textarea char count
					var tval = $('textarea').val(),
						tlength = tval.length,
						set = 0,
						remain = parseInt(set + tlength);
					$('#txtlen').text(remain);
					if (remain <= 0 && e.which !== 0 && e.charCode !== 0) {
						$('textarea').val((tval).substring(200, tlength + 1))
					}
				})
				
				
				$scope.downdloadexe = function() {
					if(tenant ===''){
						console.log("blank tenant")
						$("#myModalTenant").modal('show');
					}else{
						console.log("tenant")
						console.log("downdloadexe call")

						$("#loading").css("display", "inherit");  
						$("#downloadbtn").css("display", "none");
						  $http({
							//url :'https://192.168.1.132:9000/testAPI', //hostname+"/feedback",
							url :hostname+"/getfeedbackexe/"+tenant, //'https://saas.wowizer.com/getfeedbackexe/chjlzg9vbguzmdm4nte4nda3',
							method: "GET",
							responseType: "blob"
						  })
						 .then(function(response) {
						 $("#loading").css("display", "none");
						 $("#downloadbtn").css("display", "inherit");
						 //console.log("response.data",response.data.size)
						 if(response.data.size < 10 ){
						 console.log("getting error")
						 $("#myModal").modal('show');
						 }else{
								const url = window.URL.createObjectURL(new Blob([response.data]));
								const link = document.createElement("a");
								//console.log("link",link)
								link.href = url;
								link.setAttribute("download", "wowizer-feedback-app-0.1.0 Setup.exe");
								document.body.appendChild(link);
								link.click();
								}
						})
						 .catch(function(error) {
						 console.log("error",error)
							})
						//$("#myModal").modal('show');
					}
				
				}
				
				$scope.getFeedback = function(feedbackcomment) {
					
							
					var ele = document.getElementsByName('options');
					for(i = 0; i < ele.length; i++) {
						if(ele[i].checked){
							$scope.problem = ele[i].value;
						}
					}
					var timezone = Intl.DateTimeFormat().resolvedOptions().timeZone;
					var useragent = navigator.userAgent;
					//console.log("=>",$scope.problem, feedbackcomment);
					if($scope.problem!==undefined && $scope.problem!== '' && feedbackcomment!==undefined && feedbackcomment!==''){
					//if($scope.problem!=="" && feedbackcomment!==""){
						//console.log("Data is here");
						var date = new Date();
						//console.log("date",date)
						//console.log("useragent",useragent)
						var timestamp = Math.floor( date / 1000 );
						//console.log("browser",browser)
						$http({
							//url : "http://"+host+":8080/"+backend_folder+"/feedback.php",
							//url : "https://"+host+":3000/feedback",hostname
							//url : "https://saas.wowizer.com/feedback",
							url : hostname+"/feedback",
							method: "POST",
							headers: {
								//'Content-Type': 'application/x-www-form-urlencoded;'
								'Content-Type': 'application/json',
								'tenant': tenant //static
							},
							data:{
								'client_ip': client_ip,
								'client_timezone': timezone,
								'client_useragent':browser,
								'timestamp':timestamp,
								'feedback_source': 'EXTENSION',
								'feedback_type': $scope.problem,
								'comment': feedbackcomment,
								'user_id' : currentUser,
								'app_id': AppID.qapp.id,
								'sheet_id': CurrSheetID.sheetId,
								'AppName':appName,
								'Hostname':QlikHostname
								//"datetime": "" + date.getFullYear() + "-" + (date.getMonth() + 1) + "-" + date.getDate() + " " + date.getHours() + ":" + date.getMinutes() + ":" + date.getSeconds()
							},
							dataType: 'jsonp',
							crossDomain: true,
						}).then(function(data) {
						//console.log("data",data)
						//	console.log(data.data);
							if(data.data===true){
								
								$("#successalert").show();
								$("#feedbackform").hide();
								$("#btnfeed").hide();
								$scope.problem = "";
								$scope.feedbackcomment = "";
								$("#feedbackcomment").val("");
								var ele = document.getElementsByName('options');
								for(i = 0; i < ele.length; i++) {
									if(ele[i].checked){
										ele[i].checked = false;
									}
									//console.log(ele[i].children[0].checked)
								}
								$('#txtlen').text("0");
								setTimeout(function(){
									// console.log("success timeout")
									$('#exampleModal').modal("hide");
									$("#successalert").hide();									
									//feedbackcomment = "";
								},3000);
							}else{
								$("#tenantalert").show();
								$("#feedbackform").hide();
								setTimeout(function(){
									//console.log("external warning timeout")
									$("#tenantalert").hide();
									$("#feedbackform").show();
								},3000);
							}
						},function(err) {
							console.log(err);
							$("#erroralert").show();
							$("#feedbackform").hide();
							setTimeout(function(){
								console.log("error timeout")
								$("#erroralert").hide();
								$("#feedbackform").show();
							},3000);
						});
					}else{
						console.log("Blank");
						$("#warnalert").show();
						$("#feedbackform").hide();
						setTimeout(function(){
							//console.log("warning timeout")
							$("#warnalert").hide();
							$("#feedbackform").show();
						},3000);
					}
					
				}
			}]
		};

	} );

